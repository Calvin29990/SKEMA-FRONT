# HORS-FRONT 2026 — SKEMA, titre, dette, CDI

> **Document unique hors-front.** Tout ce qui n'est pas technique mais qui conditionne la technique. À lire avant tout cours si tu reviens après une coupure. Ce fichier remplace `PIVOT`, `POSITIONNEMENT`, `LATAM-ta-specialisation`, `ACTU-banque-par-banque`, `POSTURE`, `SELIC-NDF`, `BILAN-lectures` et les 7 fichiers `URGENCE/PLAN` de septembre. Il ne se régénère pas : il se met à jour quand un fait change (virement, réponse Marino, RDV).

---

## 1. Qui tu es — en 10 lignes

* **Calvin Minang, 02/05/2002 Libreville, 24 ans** — PGE SKEMA 2022-2027, **n° 0305476**, M2 MSc CFM Lille 2026-27, **SS 1 02 05 99 328 094 32**, passeport **18GA51536**, **07 52 97 58 09**, `calvin.minang@skema.edu`, 47 rue de Vantroyen 59800 Lille, titre **9103181806 jusqu'au 30/01/2027**.
* **CSS sans participation 01/07/2026 → 30/06/2027 + ALD 100%** — hospitalisation **avril → mi-août 2026 à Belo Horizonte** (examens passés depuis le lit d'hôpital, soutien dir. campus Gustavo Hoffmann, +55 31 9878-73232).
* **Parcours :** Concours BCE 2022 n°21446 / Ecricome 502358 → L3 → S3 fictif (anglais B2) 2023 → césure janv-déc 2024 → M1 2025 (McDonald's Mantes, contrat interrompu car SKEMA impose le semestre à l'étranger) → **M2 S6 Belo Horizonte janv. 2026 → M2 S5 Lille sept→déc 2026 → fin de scolarité décembre 2026 → jury début 2027.** Diplôme = levée d'opposabilité ≥1,5 SMIC ou carte recherche d'emploi L422-10 (12 mois, travail sans limite).
* **Emplois :** McDo Mantes 2025 (bulletins à récupérer via mesdroitssociaux.gouv.fr si besoin) + **BPCE depuis 2024 (produits)** — levier prêt collaborateur / avance / CE non encore activé.
* **Drive source :** https://drive.google.com/drive/folders/1NdzR22hAIUB3o-92rcAsyRItUtse6eBz — 100% du Drive, 61 fichiers catalogués dans `02-catalogue-drive.md`.

---

## 2. Situation académique au 22/09/2026 à 23h

* **Inscription :** M2 PGE MSc CFM Lille. **Emploi du temps S5 réactivé** le 22/09 (capture : 12/09 CORPORATE FINANCE PREREQUISITES / Virtual Teams, 09:45 ACCOUNTING PREREQUISITES, 09:00 EXCEL PREREQUISITES / Amphi C 201, CORPORATE VALUATION METHODS / Amphi C 201, CAPITAL STRUCTURE AND DIVIDEND POLICY, etc.). **K2 :** `k2.skema.edu/my/` — bandeau *"Fall 2026 K2 courses are being made available progressively"* — onglet **Current Semester** affiche désormais : ACCOUNTING PREREQUISITES, CAPITAL STRUCTURE AND DIVIDEND POLICY (0%), CORPORATE FINANCE PREREQUISITES, CORPORATE VALUATION METHODS (0%), EXCEL PREREQUISITES. **Past Semesters** reste visible (AI in Business Contexts, Climate Change...). YEP contient le détail.
* **Certificat :** **toujours bloqué par la compta** jusqu'au règlement. Attestation Belloni du 21/09 signée Maxime Belloni = seule preuve papier actuelle (ENT bloqué). C'est elle + l'emploi du temps qui servent pour le Crédit Municipal / préfecture en attendant.
* **Retard réel au 22/09 :** rentrée début septembre → 2,5 semaines manquées. Mais ce ne sont que des **prerequisites virtual teams** (compta/finance/excel) + 1 présentation M2. Pas de partiels notés, tout est rattrapable en replay + TD. Le cœur noté (Valuation, Capital Structure, Financial Reporting, Sustainable Finance, Capital Budgeting, Career Management) démarre maintenant.

---

## 3. Dette SKEMA — le fait

* **15 000€ scolarité + 4 000€ vie.** Échéancier 4×3 750€ (20/02, 20/04, **20/10, 20/12**). **Exigible au 30/09 = 7 500€** (les deux dernières). IBAN SKEMA `FR76 3000 4005 1500 0226 6006 807`, libellé **MINANG 0305476**.
* **Contacts compta :** **Beatrice Marino** `beatrice.marino@skema.edu` +33 4 93 95 44 98 + `studentaccountingoffice@skema.edu` ; **Robin Charpentier** +33 4 93 95 32 14 (bourse d'urgence, comité fin octobre, déduite du solde, réservée aux inscrits continus).
* **Virement de bonne foi :** **10,00€ fait le 22/09 à 23:33 depuis BoursoBank** (`VIR INST SKEMA BUSINESS SCHOOL PRINCIPAL, MINANG 0305476 - echeance`, capture OK, Reste Bourso 0,08€). **Ne jamais virer depuis BNP** (compte ****6696 à **-106,90€ + 60€ de lettre le 24/09 = -166,90€** prévu, 0€ sur Revolut/Bourso avant virement, risque FICP nul seuil 500€ mais frais de rejet 8-20€ si virement depuis découvert).
* **Preuve de méthode depuis 2022 :** SIGEM 2022 (800€ d'acompte manquant) → lettre d'engagement avec attestation ANBG/Campus France → dossier 1165842 → Marino lance le bon de commande → SIGEM validée. **2024** titre séjour → Axelle Sapy `axelle.sapy@skema.edu` + `residencepermitparis@skema.edu` + Ingrid Bricout CROUS Versailles contactent préfecture + Campus France. **2026 Belo** → Geneviève Poulingue `genevieve.poulingue@skema.edu` Dir. Campus Brésil + Gustavo Hoffmann `gustavo.hoffmann@skema.edu` Dir. Générale Belo (repas à l'hôpital, exams du lit, *"very proud, full support"*).
* **Proposition envoyée le 22/09 à 23h (fil Marino) :** reconnaissance de dette 7 500€ + **300€/mois dès janvier 2027 sur 25 mois** + diplôme/relevés retenus en garantie **contre certificat S5**. + engagement "je vais tout tenter d'ici le 30/09" (crowdfunding, CROUS, pairs SKEMA) mais solution réaliste = paiement à partir de janvier, validation S5 + stage correct.

---

## 4. Démarches banque par banque — vu d'un coup

| Banque / organisme | Produit demandé | Réponse | Motif |
|---|---|---|---|
| **BRED** | Grande École | ❌ | nationalité |
| **Caisse d'Épargne** | PEGE | ❌ | nationalité |
| **Crédit Agricole Nord** | étudiant | ❌ | caution |
| **Société Générale** | PEGE | ❌ | nationalité |
| **CIC Lille** (partenaire SKEMA, RDV 23/09) | PEGE FR/UE | ❌ **dit non le 23/09** | garant UE |
| **BNP** | étudiant | ❌ | — |
| **Crédit Coopératif** 0 800 171 819 (TAEG 1,92% jusqu'au 30/09) | 1 500-60k€ | ❌ | 5 ans résidence |
| **PEGE Bpifrance** | PEGE | ❌ | 2 ans résidence |
| **Smarto** (garant CGE) | | ❌ | UE uniquement |
| **MPOWER** | USA/Canada | ❌ | capacité 2026 épuisée |
| **Prodigy** | — | ❌ | SKEMA absente (404) |
| **Crédit Municipal Lille 81 rue Gantois** | **microcrédit 300-8 000€, 1,5-4%, 6-84 mois, 0 frais** | **⏳ RDV 23/09 14h — demander 7 500€, pas 20 000€** | exige ressource + 3 relevés + avis d'imposition. Prescripteur : Mission Locale, CCAS, Croix-Rouge. Fonds versés direct au créancier sous 2 semaines. Prêt sur gage possible en 1h |

**Règle :** un refus n'est jamais sur la solvabilité. Le microcrédit se joue sur **ressource régulière** → job étudiant 10-15h/sem (McDo Lille) = déclencheur (430-650€/mois) → ouvre APL ~165€/mois rétrospectifs (décret 2026-552, il faut 1h/sem déclarée) → crédibilise l'échéancier.

---

## 5. Titre de séjour — la chaîne fragile

**Sans certificat S5 → pas de renouvellement avant le 30/01/2027 → pas de fin de scolarité décembre → pas de jury → pas de diplôme → pas d'emploi → pas de remboursement. SKEMA perd 7 500€.**

* Titre étudiant = 964h/an, fin décembre = diplôme → statut salarié (≥1,5 SMIC) ou **carte recherche d'emploi L422-10 (12 mois, travail sans limite)**.
* **Frais d'urgence :** FNAU CROUS `dae.lescrous.fr` ≤3 071€, commission 2-4 semaines, sans recours — **toujours non déposé au 22/09** — + bourse d'urgence SKEMA comité fin octobre.
* **Préfecture à l'oeil :** vécu 2024 (6 mois d'attente Paris, stage BPCE écourté à mai, attestation 02/09/2024 expirée). Un report de scolarité = risque OQTF. La Préfecture suit la cohérence du parcours.

---

## 6. CDI cible — FX Sales + LatAm, Paris/France

**Un seul métier, un seul pays, un seul angle.** Structuring écarté (dérive quant). Londres écarté sauf DB (right to work). Ton Python reste un atout commercial, pas un aimant quant.

| Priorité | Banque | Pourquoi |
|---|---|---|
| 🔴 1 | **CACIB Montrouge, BNP CIB Paris 9e, SGCIB Paris, Natixis CIB Paris** | desks FX corporates / NDF BRL, franchise NDF |
| 🟠 2 | **Deutsche Bank Paris** | Autobahn, seule à publier NDF CLP/COP/PEN/BRL (Singapour 22/10/2021) |
| 🟡 3 | HSBC France, BRED (Python/VBA) | complément |
| ⚠️ | Barclays Monaco = banque privée (pas un desk FIC) | secondaire |

Contexte juin 2026 : FICC atone, equity prime explose (DB FIC +16% 2 614M€, BNP FICC -0,4% 1 404M€, SG FIC -11,3% 545M€) → ta spécialisation FX corporate est rare, donc défendable.

---

## 7. Ce qui reste à faire (checklist hors-front)

* **Ce soir :** mail 3 étapes + preuve 10€ (fait 22/09 23h30) — attendre modèle reco de Marino.
* **23/09 14h :** Crédit Municipal 81 Gantois (3 relevés BNP, attestation CSS/ALD, Belloni, contrat BPCE, proposition 7500€/25x300€). Dire titre au 30/01/2027 d'emblée.
* **Cette semaine :** **FNAU** `dae.lescrous.fr` (3071€), **bourse d'urgence SKEMA** (OneStop), **Mission Locale Lille Avenirs** `03 20 14 85 50` (prescripteur microcrédit, ne pas écrire "étudiant" mais "en fin de formation"), **BPCE employeur** (prêt collaborateur/avance/CE), **CROUS assistante sociale** (Ingrid Bricout), **pairs SKEMA** (2-3 DM ciblés : "bloqué compta Lille, qui a débloqué ton certificat ?"), **crowdfunding** en appoint seulement.
* **BNP :** réclamation à envoyer avant jeudi 24/09 (60€ lettre) : 80€ parrainage (Charlotte Robidet 12/06/2026 "3 mois max" dépassé 12/09) + annulation 60€ + OCF (plafond 25€/mois fragile, 20€/mois +200€/an avec OCF à ≤3€/mois, com. intervention 4€).
* **Garants / alternance / Londres :** clos, ne plus rouvrir.

*Dernière MAJ : 22/09/2026 23:45 — virement 10€ fait, emploi du temps + K2 Current Semester visibles, Fall 2026 en déploiement.*
